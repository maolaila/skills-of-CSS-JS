/**
 * Created by tom.chang on 2015/5/14.
 */
define(["jquery"],function(jq){
    return jq.noConflict(true);
})